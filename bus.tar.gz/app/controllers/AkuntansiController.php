<?php

class AkuntansiController extends \Phalcon\Mvc\Controller
{

    public function indexAction()
    {

    }

}

