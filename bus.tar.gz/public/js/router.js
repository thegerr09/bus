$(document).ready(function() {
	update_page('Dashboard', 'page_dashboard');
	/* Data Master  */
	update_page('Usergroup', 'page_usergroup');
	update_page('Users', 	 'page_users');
	update_page('Acl', 		 'page_acl');
	update_page('Driver', 	 'page_driver');
	update_page('CoDriver',  'page_co_driver');
	update_page('Bus', 		 'page_bus');
	update_page('Tarif', 	 'page_tarif');
	update_page('Setting', 	 'page_setting');
	/* booking  */
	update_page('Booking',     'page_booking');
	update_page('GrafikOrder', 'page_grafik_order');
});

function load_page(page_content, link, storage){
	update_page(link, storage);
	
	if (link == '#') { return false; }
	
	if(page_content == '' || page_content == null){
		$.ajax({
	        method: "GET",
	        dataType: "html",
	        url: link,
	        success: function(res){
	            $('.content-wrapper').html(res);
	            localStorage.setItem(storage,res);
	        }
	    });
	}else{
		var page_content = localStorage.getItem(storage);
		$('.content-wrapper').html(page_content);
	}
	return false;
}

function reload_page(link, storage){
	if (link == '#') {return false;}
	$.ajax({
        method: "GET",
        dataType: "html",
        url: link,
        success: function(res){
            $('.content-wrapper').html(res);
            localStorage.setItem(storage,res);
        }
    });
    return false;
}

function update_page(link, storage){
	if (link == '#') {return false;}
	$.ajax({
        method: "GET",
        dataType: "html",
        url: link,
        success: function(res){
            localStorage.setItem(storage,res);
        }
    });
    return false;
}