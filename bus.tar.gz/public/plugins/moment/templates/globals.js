/*global window:false*/

import moment from "./moment";

window.moment = moment;
