<style>
#except:hover{
  cursor: pointer;
  background-color: rgba(209,197,197,0.25);
}
.usergroup{
  cursor: pointer;
  color: #807c7c;
}
</style>
<section class="content-header animated fadeIn">
  <h1>Access Control List</h1>
  <ol class="breadcrumb">
    <li><i class="fa fa-home"></i> Home</li>
    <li class="active">acl</li>
  </ol>
</section>

<section class="content animated fadeIn">
  <div class="row">

    <div class="col-md-12">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">List Acl</h3>
          <div class="box-tools pull-right" style="margin-top:2px;">
            <button type="button" class="btn btn-xs btn-primary" data-toggle="modal" data-target="#Tambah">
              <i class="fa fa-plus-circle"></i> Tambah
            </button>
          </div>
        </div>
        <div class="box-body" id="list_view">
          <table id="example" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>No</th>
                <th>Action</th>
                <th>Controller</th>
                <th>Action</th>
                <?php foreach ($this->AclAction->usergroup() as $ug) { ?>
                <th><?= $ug->usergroup ?></th>
                <?php } ?>
                <th>Except</th>
              </tr>
            </thead>
            <tbody>
              <?php $no = 1; ?>
              <?php foreach ($acl as $x) { ?>
              <tr>
                <td><?= $no ?></td>
                <td>
                  <i class="fa fa-edit cursor" style="font-size:18px;"></i> |
                  <i class="fa fa-trash cursor" style="font-size:18px;"></i> |
                  <i class="fa fa-power-off cursor text-green" style="font-size:18px;"></i> |
                  <span class="label bg-green">Active</span>
                </td>
                <td><?= $x->controller ?></td>
                <td><?php if (isset($x->action)) { ?><?= $x->action ?><?php } else { ?>{default index}<?php } ?></td>
                <?php foreach ($this->AclAction->usergroup() as $ug) { ?>
                <td align="center">
                  <label class="usergroup">
                    <input type="checkbox" class="flat-blue check" value="<?= $x->id ?>,<?= $ug->id ?>"
                    <?php if ($this->isIncluded($ug->id, $this->AclAction->acl_usergroup($x->usergroup))) { ?>checked<?php } ?>>
                  </label>
                </td>
                <?php } ?>
                <td style="padding: 0px;"><div ondblclick="return except(this)" style="padding: 10px;" acl="<?= $x->id ?>"><?= $x->except ?></div></td>
              </tr>
              <?php $no = $no + 1; ?>
              <?php } ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>
</section>

<!-- include JS -->
<div class="modal fade" id="Tambah" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="clear_form()">
          <span aria-hidden="true">&times;</span>
        </button>
        <h4 class="modal-title" id="label_usergroup">Input Acl</h4>
      </div>

      <form name="group" action="<?= $this->url->get('Acl/input') ?>" method="POST" data-remote="data-remote">
        <div class="modal-body">
          <div class="form-group">
            <label>Controller</label>
            <input type="text" name="controller" class="form-control" placeholder="Controller">
          </div>
          <div class="form-group">
            <label>Action</label>
            <input type="text" name="actions" class="form-control" placeholder="Action"> 
          </div>
          <div class="form-group">
            <label>Usergroup</label><br>
            <?php foreach ($this->AclAction->usergroup() as $ug) { ?>
            <td align="center">
              <label class="usergroup">
                <input type="checkbox" name="usergroup[]" class="flat-blue tambah" value="<?= $ug->id ?>"> <?= $ug->usergroup ?>
              </label><br>
            </td>
            <?php } ?>
          </div>
          <div class="form-group">
            <label>Except</label>
            <textarea name="except" class="form-control" placeholder="Except usergroup ..."></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal" onclick="clear_form()">Close</button>
          <button type="submit" class="btn btn-success">Save</button>
        </div>
      </form>

    </div>
  </div>
</div>

<!-- include JS -->
<script type="text/javascript" class="init">
$(document).ready(function() {
	var table = $('#example').DataTable( {
		scrollY:        "310px",
		dom: 			'<"pull-left"f><"pull-right"i>tip',
		scrollX:        true,
		scrollCollapse: true,
		paging:         false,
      	lengthChange: 	false,
        ordering: 		false,
		columnDefs: [
	        { "width": "25px",  "targets": [0] },
	        { "width": "128px", "targets": [1] },
	        { "width": "100px", "targets": [2] },
	        { "width": "100px", "targets": [3] },
	        { "width": "80px",  "targets": [4] },
	        { "width": "80px",  "targets": [5] },
	        { "width": "80px",  "targets": [6] },
	        { "width": "80px",  "targets": [7] },
	        { "width": "150px", "targets": [8] }
    	]
	});
	new $.fn.dataTable.FixedColumns( table, {
		leftColumns: 4,
	});
});

$('input[type="checkbox"].flat-blue').iCheck({
	checkboxClass: 'icheckbox_flat-blue'
});

$('.usergroup').on('ifChecked', 'input[type="checkbox"].flat-blue.check', function(event) {
	var val = $(this).val();
	var res = val.split(",");
	
    $.ajax({
      type: 'POST',
      url: 'Acl/access',
      dataType:'json',
      data: 'acl_id='+res[0]+'&ug_id='+res[1],
      success: function(response){
        new PNotify({
          title: response.title,
          text: response.text,
          type: response.type
        });
        update_page('Acl', 'page_acl');
      }
    });
}).on('ifUnchecked', 'input[type="checkbox"].flat-blue.check', function(event) {
	var val = $(this).val();
	var res = val.split(",");
	
    $.ajax({
      type: 'POST',
      url: 'Acl/access',
      dataType:'json',
      data: 'acl_id='+res[0]+'&ug_id='+res[1],
      success: function(response){
        new PNotify({
          title: response.title,
          text: response.text,
          type: response.type
        });
        update_page('Acl', 'page_acl');
      }
    });
});

$('.except').keyup(function(event) {
    newText = event.target.value;
    $('textarea.except').attr('textval', newText);
    console.log(newText);
});

function except(that) {
	var isi = $(that).html().trim();
	var id  = $(that).attr('acl');
	$(that).parent().html('<textarea class="form-control" onblur="return except_back(this)" style="width:100%; height:100%;" acl="'+id+'">'+isi+'</textarea>').click(); 
    $(that).parent().find('textarea').focus();
	return false;
}
function except_back(that){
	var isi = $(that).val();
	var id  = $(that).attr('acl');
	$(that).parent().html('<div ondblclick="return except(this)" style="padding: 10px;" acl="'+id+'">'+isi+'</div>');
	$.ajax({
        method: "POST",
        dataType: "json",
        url: 'Acl/except',
        data: 'id='+id+'&except='+isi,
        success: function(response){
	        new PNotify({
	          title: response.title,
	          text: response.text,
	          type: response.type
	        });
	        update_page('Acl', 'page_acl');
        }
    });
    return false;
}

(function() {

  $('form[data-remote]').on('submit', function(e) {
    var form = $(this);
    var url = form.prop('action');

    $.ajax({
      type: 'POST',
      url: url,
      dataType:'json',
      data: form.serialize(),
      success: function(response){
        new PNotify({
          title: response.title,
          text: response.text,
          type: response.type
        });
        update_page('Acl', 'page_acl');
        clear_form(response.close);
        list();
      }
    });
 
    e.preventDefault();
  });

})();

function list() {
  $.ajax({
    type: 'GET',
    url: '<?= $this->url->get('Acl/list') ?>',
    dataType:'html',
    success: function(response){
      $('#list_view').html(response).iCheck({
        checkboxClass: 'icheckbox_flat-blue'
      });
      var table = $('#example').DataTable( {
        scrollY:        "310px",
        dom:      '<"pull-left"f><"pull-right"i>tip',
        scrollX:        true,
        scrollCollapse: true,
        paging:         false,
            lengthChange:   false,
            ordering:     false,
        columnDefs: [
              { "width": "25px",  "targets": [0] },
              { "width": "128px", "targets": [1] },
              { "width": "100px", "targets": [2] },
              { "width": "100px", "targets": [3] },
              { "width": "80px",  "targets": [4] },
              { "width": "80px",  "targets": [5] },
              { "width": "80px",  "targets": [6] },
              { "width": "80px",  "targets": [7] },
              { "width": "150px", "targets": [8] }
          ]
      });
      new $.fn.dataTable.FixedColumns( table, {
        leftColumns: 4,
      });
    }
  });
}

function clear_form(id){
  $('form[name="group"]').find('[name]').not('input[name^="usergroup"]').val('');
  $('input[type="checkbox"].flat-blue.tambah').iCheck('uncheck');
  if (id == '1') {
    $('#Tambah').modal('hide');
  } else {
    $('#label_users').text('Input Users');
    $('form[name="form"]').attr('action', '<?= $this->url->get('Acl/input') ?>');
    var btn_submit = $('form[name="form"]').find('button[type="submit"]');
    btn_submit.removeClass('btn-primary');
    btn_submit.addClass('btn-success');
    btn_submit.text('Save');
  }
}
</script>