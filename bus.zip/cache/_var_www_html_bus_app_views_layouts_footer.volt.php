<footer class="main-footer">
  <strong>Copyright &copy; 2016 <a href="http://qodr.or.id">Qodr.or.id</a></strong>
  <span class="pull-right"><b>Version</b> : 1.0.1</span>
</footer>