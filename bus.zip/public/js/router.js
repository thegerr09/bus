$(document).ready(function() {
	update_page('Dashboard', 'page_dashboard');
	update_page('Usergroup', 'page_usergroup');
	update_page('Users', 'page_users');
	update_page('Acl', 'page_acl');
});

function load_page(page_content, link, storage){
	update_page(link, storage);
	
	if (link == '#') { return false; }
	
	if(page_content == '' || page_content == null){
		$.ajax({
	        method: "GET",
	        dataType: "html",
	        url: link,
	        success: function(res){
	            $('.content-wrapper').html(res);
	            localStorage.setItem(storage,res);
	        }
	    });
	}else{
		var page_content = localStorage.getItem(storage);
		$('.content-wrapper').html(page_content);
	}
	return false;
}

function reload_page(link, storage){
	if (link == '#') {return false;}
	$.ajax({
        method: "GET",
        dataType: "html",
        url: link,
        success: function(res){
            $('.content-wrapper').html(res);
            localStorage.setItem(storage,res);
        }
    });
    return false;
}

function update_page(link, storage){
	if (link == '#') {return false;}
	$.ajax({
        method: "GET",
        dataType: "html",
        url: link,
        success: function(res){
            localStorage.setItem(storage,res);
        }
    });
    return false;
}