<?php

class BusController extends \Phalcon\Mvc\Controller
{

    public function indexAction()
    {

    }

}

